<?php
include('Base.php');
include('UserApi.php');
include('RegistrarApi.php');
$token = '';

/*
$api = new Yandex_Mail_UserApi($token, null, true);
$api->createUser('test', 'test12');
$api->editUserDetails('test', 'asdasd', 'test', 'test', 2);
$api->getUnreadMessagesCount('test');
$api->getUserInfo('test');
$api->getUsersList('test');
$api->deleteUser('test');

$api->setImportSettings('pop3', 'pop3.mail.ru');
$api->startImport('test', 'test', 'test');
$api->getImportState('me');
$api->stopImport('me');
$api->registerAndStartImport('me', 'test', 'test', 'test');

$registrarApi = new Yandex_Mail_Api_RegistrarApi('5791747', 'qweasdqwe', null, true);
$registrarApi->setRegistrarUrls('http://asd/', 'http://asdasd', 'http://asdasd', 'http://asdasd', 'http://asdasd');
$registrarApi->importDomain('test.ru', 'pop3', false, 'test.ru', 110, array('tes@test.ru' => 'asdasd'));
$registrarApi->checkDomain('test.ru');
$registrarApi->checkImport('test.ru');
*/
    